//package com.onlineShopping.Shophub.entity;
//
//import java.time.LocalDate;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.OneToOne;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.Pattern;
//import javax.validation.constraints.Size;
//
//import com.onlineShopping.Shophub.entity.Users;
//
//
//@Entity
//public class Seller extends Users {
//	@Id
//	@Column(name="SellerID")
//	private int sellerID;
//	
//	@NotEmpty(message = "BusinessName can't be Empty.")
//    @Size(min = 2, max = 40, message = "Minimum 2 and maximum 40 characters allowed.")
//	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only Alphabets are Allowed.")
//	@Column(name="BusinessName",length=40)
//	private String businessName;
//	
//    @Size(min = 2, max = 255, message = "Minimum 2 and maximum 255 characters allowed.")
//	@Pattern(regexp = "^[a-zA-Z0-9\\\\s]*$", message = "Only Alphabets,numeric value are Allowed.")
//	@Column(name="BusinessDescription",length=255)
//	private String businessDescription;
//    
//    @Size(min=1,max =20, message = "Minimum 1 and maximum 20 characters allowed.")
//	@Pattern(regexp = "^[0-9]*$", message = "Only digit are Allowed")
//	@Column(name="CommissionRate")
//	private int commissionRate;
//
//    
//	@OneToOne(mappedBy="seller",cascade=CascadeType.ALL)
//	Users users;
//	
//
//	public int getSellerID() {
//		return sellerID;
//	}
//
//	public void setSellerID(int sellerID) {
//		this.sellerID = sellerID;
//	}
//
//	public String getBusinessName() {
//		return businessName;
//	}
//
//	public void setBusinessName(String businessName) {
//		this.businessName = businessName;
//	}
//
//	public String getBusinessDescription() {
//		return businessDescription;
//	}
//
//	public void setBusinessDescription(String businessDescription) {
//		this.businessDescription = businessDescription;
//	}
//
//	public int getCommissionRate() {
//		return commissionRate;
//	}
//
//	public void setCommissionRate(int commissionRate) {
//		this.commissionRate = commissionRate;
//	}
//
//	public Users getUsers() {
//		return users;
//	}
//
//	public void setUsers(Users users) {
//		this.users = users;
//	}
//
//	public Seller(int userID, String userName, String email, String password, String phoneNumber, String userType,
//			LocalDate registrationDate, int sellerID,
//			@NotEmpty(message = "BusinessName can't be Empty.") @Size(min = 2, max = 40, message = "Minimum 2 and maximum 40 characters allowed.") @Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only Alphabets are Allowed.") String businessName,
//			@Size(min = 2, max = 255, message = "Minimum 2 and maximum 255 characters allowed.") @Pattern(regexp = "^[a-zA-Z0-9\\\\s]*$", message = "Only Alphabets,numeric value are Allowed.") String businessDescription,
//			@Size(min = 1, max = 20, message = "Minimum 1 and maximum 20 characters allowed.") @Pattern(regexp = "^[0-9]*$", message = "Only digit are Allowed") int commissionRate,
//			Users users) {
//		super(userID, userName, email, password, phoneNumber, userType, registrationDate);
//		this.sellerID = sellerID;
//		this.businessName = businessName;
//		this.businessDescription = businessDescription;
//		this.commissionRate = commissionRate;
//		this.users = users;
//	}
//
//	public Seller() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Seller(int userID, String userName, String email, String password, String phoneNumber, String userType,
//			LocalDate registrationDate) {
//		super(userID, userName, email, password, phoneNumber, userType, registrationDate);
//		// TODO Auto-generated constructor stub
//	}
//
//    
//    
//	
//    
//
//}
